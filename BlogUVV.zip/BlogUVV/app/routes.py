from app import app
from flask import render_template

@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'Pedro'}
    posts = [
        {
            'author': {'username': 'Joao'},
            'body': 'A beautiful sunny day in Hell'
        },
        {
            'author': {'username': 'Maria'},
            'body': 'Its over, theres no reason to fight anymore'
        }
    ]
    return render_template('index.html', title='Home', user=user, posts=posts)
